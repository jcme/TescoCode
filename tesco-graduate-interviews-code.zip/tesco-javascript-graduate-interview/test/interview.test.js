const { assert } = require('chai')
const { process } = require('../index')

describe("Interview Tests", () => {
    it('should test specific functionality', () => {
      assert.fail('Not yet implemented')
    })
})
