import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

public class JUnitInterviewTest {

    private Interview interview;

    @Before
    public void setUp() {
        interview = new Interview();
    }

    @Test
    public void sumTest() {
        fail("No test written yet");
    }

}
